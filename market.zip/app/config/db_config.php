<?php
CONST HOST = "localhost";
CONST USER = "root";
CONST PASS = "rahekoller";
CONST DB_NAME = "market_challenger";